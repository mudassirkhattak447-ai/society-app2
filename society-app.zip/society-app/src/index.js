const TEAMS = ['Leadership', 'Media', 'Events', 'Discipline'];
const LEADERS = ['President', 'Chairman', 'Secretary'];
// Core Team = anyone with a Leadership role OR who is a team head (derived live from data)
const CORE_SQL = "(team='Leadership' OR is_head=1)";

const json = (d, s = 200, h = {}) =>
  new Response(JSON.stringify(d), { status: s, headers: { 'Content-Type': 'application/json', ...h } });
const err = (m, s = 400) => json({ error: m }, s);
const clean = (s, n) => String(s ?? '').trim().slice(0, n);

const enc = new TextEncoder();
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
const unhex = h => new Uint8Array(h.match(/../g).map(x => parseInt(x, 16)));
async function hash(pw, salt) {
  const k = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  return hex(await crypto.subtle.deriveBits(
    { name: 'PBKDF2', hash: 'SHA-256', salt: unhex(salt), iterations: 100000 }, k, 256));
}

async function createUser(env, email, password, memberId, isAdmin) {
  email = clean(email, 200).toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Invalid email');
  if (String(password || '').length < 10) throw new Error('Password must be at least 10 characters');
  const salt = hex(crypto.getRandomValues(new Uint8Array(16)));
  await env.DB.prepare('INSERT INTO users (email, pass_hash, salt, member_id, is_admin) VALUES (?,?,?,?,?)')
    .bind(email, await hash(password, salt), salt, memberId || null, isAdmin ? 1 : 0).run();
}

async function getUser(req, env) {
  const c = (req.headers.get('Cookie') || '').match(/(?:^|;\s*)sid=([a-f0-9]{64})/);
  if (!c) return null;
  return await env.DB.prepare(
    `SELECT u.id, u.email, u.is_admin, u.member_id
       FROM sessions s JOIN users u ON u.id = s.user_id
       LEFT JOIN members m ON m.id = u.member_id
      WHERE s.token = ? AND s.expires > ? AND u.active = 1 AND (m.id IS NULL OR m.active = 1)`
  ).bind(c[1], Date.now()).first();
}

async function isCore(env, u) {
  if (!u.member_id) return false;
  return !!(await env.DB.prepare(
    `SELECT 1 FROM member_roles WHERE member_id = ? AND ${CORE_SQL} LIMIT 1`).bind(u.member_id).first());
}

// `where` is always a constant string from this file, never user input
async function loadMembers(env, where) {
  const { results } = await env.DB.prepare(
    `SELECT m.id, m.name, m.department, m.bio, m.photo_key, m.published, m.active,
            r.id rid, r.team, r.title, r.is_head
       FROM members m LEFT JOIN member_roles r ON r.member_id = m.id
      WHERE ${where} ORDER BY m.name`).all();
  const map = new Map();
  for (const x of results) {
    if (!map.has(x.id)) map.set(x.id, { id: x.id, name: x.name, department: x.department, bio: x.bio,
      photo_key: x.photo_key, published: x.published, active: x.active, roles: [] });
    if (x.rid) map.get(x.id).roles.push({ id: x.rid, team: x.team, title: x.title, is_head: x.is_head });
  }
  return [...map.values()];
}

function imageType(b) {
  if (b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF) return ['jpg', 'image/jpeg'];
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4E && b[3] === 0x47) return ['png', 'image/png'];
  if (String.fromCharCode(...b.slice(0, 4)) === 'RIFF' && String.fromCharCode(...b.slice(8, 12)) === 'WEBP')
    return ['webp', 'image/webp'];
  return null;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url), p = url.pathname, m = req.method;
    try {
      // ---------- photos (public read) ----------
      if (p.startsWith('/photo/')) {
        const o = await env.PHOTOS.get(p.slice(7));
        if (!o) return new Response('Not found', { status: 404 });
        return new Response(o.body, { headers: {
          'Content-Type': o.httpMetadata?.contentType || 'image/jpeg',
          'Cache-Control': 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff' } });
      }
      if (!p.startsWith('/api/')) return env.ASSETS.fetch(req);

      // ---------- public ----------
      if (p === '/api/public/members' && m === 'GET')
        return json(await loadMembers(env, 'm.published = 1 AND m.active = 1'));

      // ---------- first-time admin setup (works once, needs SETUP_KEY secret) ----------
      if (p === '/api/setup' && m === 'POST') {
        const b = await req.json();
        const n = await env.DB.prepare('SELECT COUNT(*) c FROM users').first();
        if (n.c > 0 || !env.SETUP_KEY || b.key !== env.SETUP_KEY) return err('Forbidden', 403);
        await createUser(env, b.email, b.password, null, 1);
        return json({ ok: true });
      }

      // ---------- login / logout ----------
      if (p === '/api/login' && m === 'POST') {
        const b = await req.json();
        const u = await env.DB.prepare('SELECT * FROM users WHERE email = ? AND active = 1')
          .bind(clean(b.email, 200).toLowerCase()).first();
        if (!u || (await hash(String(b.password || ''), u.salt)) !== u.pass_hash)
          return err('Invalid email or password', 401);
        const t = hex(crypto.getRandomValues(new Uint8Array(32)));
        await env.DB.prepare('INSERT INTO sessions VALUES (?,?,?)').bind(t, u.id, Date.now() + 7 * 864e5).run();
        return json({ ok: true }, 200,
          { 'Set-Cookie': `sid=${t}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=604800` });
      }
      if (p === '/api/logout' && m === 'POST') {
        const c = (req.headers.get('Cookie') || '').match(/sid=([a-f0-9]{64})/);
        if (c) await env.DB.prepare('DELETE FROM sessions WHERE token = ?').bind(c[1]).run();
        return json({ ok: true }, 200, { 'Set-Cookie': 'sid=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0' });
      }

      const user = await getUser(req, env);

      if (p === '/api/me')
        return json({ user: user ? { email: user.email, is_admin: !!user.is_admin, is_core: await isCore(env, user) } : null });

      // ---------- private Core Team (server-side check) ----------
      if (p === '/api/core') {
        if (!user) return err('Please log in', 401);
        if (!(await isCore(env, user))) return err('Core Team members only', 403);
        return json(await loadMembers(env,
          `m.active = 1 AND m.id IN (SELECT member_id FROM member_roles WHERE ${CORE_SQL})`));
      }

      // ---------- admin only ----------
      if (p.startsWith('/api/admin/')) {
        if (!user || !user.is_admin) return err('Admins only', 403);
        let r;

        if (p === '/api/admin/members' && m === 'GET') return json(await loadMembers(env, '1=1'));

        if (p === '/api/admin/members' && m === 'POST') {
          const b = await req.json(), name = clean(b.name, 100);
          if (!name) return err('Name is required');
          const x = await env.DB.prepare('INSERT INTO members (name, department, bio, published) VALUES (?,?,?,?)')
            .bind(name, clean(b.department, 100), clean(b.bio, 500), b.published ? 1 : 0).run();
          return json({ id: x.meta.last_row_id });
        }

        if ((r = p.match(/^\/api\/admin\/members\/(\d+)$/))) {
          const id = +r[1];
          if (m === 'PUT') {
            const b = await req.json(), name = clean(b.name, 100);
            if (!name) return err('Name is required');
            await env.DB.prepare('UPDATE members SET name=?, department=?, bio=?, published=?, active=? WHERE id=?')
              .bind(name, clean(b.department, 100), clean(b.bio, 500), b.published ? 1 : 0, b.active ? 1 : 0, id).run();
            return json({ ok: true });
          }
          if (m === 'DELETE') {
            const old = await env.DB.prepare('SELECT photo_key FROM members WHERE id=?').bind(id).first();
            await env.DB.batch([
              env.DB.prepare('DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE member_id=?)').bind(id),
              env.DB.prepare('DELETE FROM users WHERE member_id=?').bind(id),
              env.DB.prepare('DELETE FROM member_roles WHERE member_id=?').bind(id),
              env.DB.prepare('DELETE FROM members WHERE id=?').bind(id)]);
            if (old?.photo_key) await env.PHOTOS.delete(old.photo_key);
            return json({ ok: true });
          }
        }

        if ((r = p.match(/^\/api\/admin\/members\/(\d+)\/photo$/))) {
          const id = +r[1];
          const old = await env.DB.prepare('SELECT photo_key FROM members WHERE id=?').bind(id).first();
          if (!old) return err('Member not found', 404);
          if (m === 'PUT') {
            const buf = await req.arrayBuffer();
            if (buf.byteLength > 2 * 1024 * 1024) return err('Image must be under 2 MB');
            if (buf.byteLength < 12) return err('Invalid image');
            const t = imageType(new Uint8Array(buf));
            if (!t) return err('Only JPG, PNG or WebP images are allowed');
            const key = crypto.randomUUID() + '.' + t[0];
            await env.PHOTOS.put(key, buf, { httpMetadata: { contentType: t[1] } });
            await env.DB.prepare('UPDATE members SET photo_key=? WHERE id=?').bind(key, id).run();
            if (old.photo_key) await env.PHOTOS.delete(old.photo_key);
            return json({ ok: true });
          }
          if (m === 'DELETE') {
            await env.DB.prepare('UPDATE members SET photo_key=NULL WHERE id=?').bind(id).run();
            if (old.photo_key) await env.PHOTOS.delete(old.photo_key);
            return json({ ok: true });
          }
        }

        if ((r = p.match(/^\/api\/admin\/members\/(\d+)\/roles$/)) && m === 'POST') {
          const id = +r[1], b = await req.json(), title = clean(b.title, 60);
          if (!TEAMS.includes(b.team)) return err('Unknown team');
          if (!title) return err('Title is required');
          if (b.team === 'Leadership' && !LEADERS.includes(title))
            return err('Leadership titles: President, Chairman or Secretary');
          const stmts = [];
          if (b.team === 'Leadership')   // only one holder per leadership post
            stmts.push(env.DB.prepare("DELETE FROM member_roles WHERE team='Leadership' AND title=?").bind(title));
          const head = b.is_head && b.team !== 'Leadership' ? 1 : 0;
          if (head)                      // only one head per team
            stmts.push(env.DB.prepare('UPDATE member_roles SET is_head=0 WHERE team=?').bind(b.team));
          stmts.push(env.DB.prepare('INSERT INTO member_roles (member_id, team, title, is_head) VALUES (?,?,?,?)')
            .bind(id, b.team, title, head));
          await env.DB.batch(stmts);
          return json({ ok: true });
        }

        if ((r = p.match(/^\/api\/admin\/roles\/(\d+)$/)) && m === 'DELETE') {
          await env.DB.prepare('DELETE FROM member_roles WHERE id=?').bind(+r[1]).run();
          return json({ ok: true });
        }

        if (p === '/api/admin/users' && m === 'POST') {
          const b = await req.json();
          await createUser(env, b.email, b.password, b.member_id ? +b.member_id : null, b.is_admin);
          return json({ ok: true });
        }
        return err('Not found', 404);
      }
      return err('Not found', 404);
    } catch (e) {
      const msg = String(e.message || e);
      if (/UNIQUE/.test(msg)) return err('That email already exists');
      if (/JSON/.test(msg)) return err('Bad request');
      if (/^(Invalid|Password)/.test(msg)) return err(msg);
      return err('Server error', 500);
    }
  }
};
