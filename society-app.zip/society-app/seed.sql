-- SAMPLE DATA ONLY: replace with real members from the Admin page
INSERT INTO members (name, department, published) VALUES
 ('Sample President', 'Sample Dept, Year 4', 1),
 ('Sample Chairman', 'Sample Dept, Year 4', 1),
 ('Sample Secretary', 'Sample Dept, Year 3', 1),
 ('Sample Media Head', 'Sample Dept, Year 3', 1),
 ('Sample Media Member', 'Sample Dept, Year 2', 1),
 ('Sample Events Head', 'Sample Dept, Year 3', 1),
 ('Sample Events Member', 'Sample Dept, Year 2', 1),
 ('Sample Discipline Head', 'Sample Dept, Year 3', 1),
 ('Sample Discipline Member', 'Sample Dept, Year 2', 1);
INSERT INTO member_roles (member_id, team, title, is_head) VALUES
 (1,'Leadership','President',0),
 (2,'Leadership','Chairman',0),
 (3,'Leadership','Secretary',0),
 (4,'Media','Head of Media Team',1),
 (5,'Media','Designer',0),
 (6,'Events','Head of Event Management Team',1),
 (7,'Events','Coordinator',0),
 (8,'Discipline','Head of Discipline Team',1),
 (9,'Discipline','Volunteer',0);
